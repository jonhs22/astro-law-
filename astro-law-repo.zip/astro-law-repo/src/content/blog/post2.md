---
title: "Overview of Greek Civil Law"
lang: "en"
date: "2025-08-07"
excerpt: "Civil law in Greece regulates personal and property relations and is organised into five books."
slug: "post2"
---

Greek civil law is a cornerstone of the country’s private law. It governs
relations between individuals and property and contrasts with commercial and
labour law, the other two branches of private law【960259837252033†L36-L44】.
According to Article 1 of the Civil Code, the primary sources of civil law are
statutes and custom; the Greek Constitution also recognises general rules
of international law and ratified treaties as sources of law【960259837252033†L36-L43】.
Unlike common law systems, judicial precedent is not a binding source of law in
Greece, although court decisions may influence other courts when reasoning on
similar disputes【960259837252033†L45-L52】.

The Greek Civil Code was enacted in 1946 and remains in force today. It is
divided into five books: General Principles, Contract Law, Property Law,
Family Law and Inheritance Law【960259837252033†L64-L71】. Each book
addresses a different area of civil relations. The book on Property Law
(Articles 947–1345) sets out the main property rights recognised in Greece.
Article 973 enumerates these rights, including ownership—the most extensive
real right—servitudes, pledges and mortgages【960259837252033†L112-L117】.
Possession is treated as a factual situation rather than a right【960259837252033†L118-L119】.

Family law is contained in Articles 1346–1709 and regulates marriage,
divorce, parent–child relations, guardianship and adoption【960259837252033†L124-L130】.
This area of law has undergone significant reforms to align with modern social
realities, such as the introduction of civil marriage in the 1980s and the
recognition of civil partnerships for same‑sex couples【960259837252033†L135-L145】.

By understanding the structure and sources of Greek civil law, legal
professionals and laypersons alike can better navigate issues involving
contracts, property and family relations.