---
title: "Understanding the Greek Constitution"
lang: "en"
date: "2025-08-07"
excerpt: "An overview of Greece’s constitutional framework, including separation of powers and the status of international law."
slug: "post1"
---

The Constitution of the Hellenic Republic establishes Greece as a parliamentary
republic. It proclaims that all powers derive from the people and exist for
the people and the nation. Article 26 formalizes the separation of powers by
assigning legislative authority to the Parliament and the President of the
Republic, executive authority to the President and the Government, and
judicial authority to the courts【698357352313552†L910-L924】. This clear
delineation prevents the concentration of power and ensures a system of checks
and balances.

Article 28 integrates the “generally recognised rules of international law”
and ratified international conventions into domestic law and provides that
they prevail over any contrary statute【698357352313552†L934-L959】. This
clause anchors Greece within the international community and underlines the
importance of European Union law and other treaties in the domestic legal
order.

The Greek Parliament is unicameral and consists of 300 members elected for a
four‑year term【582430503634663†L95-L117】. Together with the President,
Parliament enacts laws, which are promulgated in the National Gazette.
Understanding this constitutional framework is essential for navigating Greek
public life and legal processes.