import { defineConfig } from "astro/config";

/**
 * Astro configuration
 *
 * The site property is used for generating canonical URLs. Update this if you
 * deploy the site to a public domain. For local development this can be left
 * undefined.
 */
export default defineConfig({
  site: undefined,
  markdown: {
    remarkPlugins: [],
    rehypePlugins: [],
  },
});